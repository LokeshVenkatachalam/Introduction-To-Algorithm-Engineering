# Assignment 2

## Running code 

- `python3 2020111017_sc.py <input text file 1> <input text file 2>`

- For running without blocking , comment the code after running `# 1 level blocking `

- For running with blocking , comment the code from `# No blocking ` to `# 1 level blocking `

- if u want time taken for program to run uncomment the `#print(et-st)`

- To change blocking size , change `s1`

